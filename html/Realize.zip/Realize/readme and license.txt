********************************************************************
	SPYKA WEBMASTER - HTTP://WWW.SPYKA.NET
	FREE WEB TEMPLATES AND RESOURCES FOR WEBMASTERS
********************************************************************

This is a free web template by spyka webmaster (http://www.spyka.net)



1. Customizing this template
-----------------------------------------
To change the text, content, links etc. open the index.html in your preferred HTML editor, 
whether it be notepad, dreamweaver or frontpage.

To change the CSS open styles.css in a HTML/CSS editor and change the appropriate 
values to suit your needs.

Need more help? Try our webmaster forums - http://spyka.net/forums


2. Terms of use/License
-----------------------------------------
This template has been released under a Creative Commons Attribution license, this means you can use the template as 
long as a visible link to spyka Webmaster (http://www.spyka.net) remains in the footer.
 
This condition can be waived by purchasing a template license for �5.00 (See 4. Template License in this document)

For more information of the license: http://creativecommons.org/licenses/by/3.0/


3. Template License
-----------------------------------------
The link back to spyka.net and any other copyright/information relating to spyka.net can 
be removed with the purchase of a template license. A license costs �5.00 (Approx $7USD) 
per template per site and gives the site owner/webmaster the right to remove this information.

To purchase a license or for more information see: http://www.spyka.net/licensing


4. Other information
-----------------------------------------
Please contact us if you need more information about template licences, use of our templates
or other queries - spyka.net/contact
