<?php

    function online() {
        $page = file_get_contents('tpl/online.tpl');
        display($page);
    }