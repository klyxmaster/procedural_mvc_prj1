<?php

    function ErrorLog($msg) {
        echo $msg;
    }