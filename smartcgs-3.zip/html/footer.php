   </div>
        <div id="footer">
        	<p>&copy; <?=SITE_NAME;?> <?=date("Y",time());?>.
         Design by <a href="mailto:xra7en@gmail.com" target="_blank">xRa7eN</a> |
         
        </div>
     </div>