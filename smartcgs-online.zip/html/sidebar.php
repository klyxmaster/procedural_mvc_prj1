<div class="sidebar">
        <ul>	
           <li>
                <h4>Categories</h4>
                <ul class="blocklist">
					
					<li><a href="<?=URL;?>genre/94">Tycoon</a></li>
					<li><a href="<?=URL;?>genre/87">Space Games</a></li>
					<li><a href="<?=URL;?>genre/82">RPG Games</a></li>
					<li><a href="<?=URL;?>genre/15">Hidden Object</a></li>
					<li><a href="<?=URL;?>genre/84">SIM Games</a></li>
					<li><a href="<?=URL;?>genre/57">Fantasy Game</a></li>
					<li><a href="<?=URL;?>genre/58">Farm Games</a></li>
					<li><a href="<?=URL;?>genre/29">Strategy </a></li>
					<li><a href="<?=URL;?>genre/17">Match 3</a></li>
					<li><a href="<?=URL;?>genre/5">Card Games</a></li>
					<li><a href="<?=URL;?>genre/89">Tower Defense</a></li>
					<li><a href="<?=URL;?>genre_x">More Categories....</a></li>
                </ul>
            </li>            
		</ul>
    </div>

    <div class="clear"></div>
</div>
</body>
</html>
